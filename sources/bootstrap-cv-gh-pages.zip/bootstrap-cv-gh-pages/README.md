# Bootstrap Resume OR CV Template Free
[![Gratipay](http://img.shields.io/gratipay/jQuery2DotNet.svg)](https://gratipay.com/jQuery2DotNet/)

Simple, clear, cool and responsive CV/Resume template. Professional looking resume template. :smile:

[DEMO](http://jquery2dotnet.github.io/bootstrap-cv/)

Features
----------
- Responsive design.
- Simple and clear UI
- Cool CSS animation.
- One page resume Template.
- Work experience
- Skill
- Languages
- Published
- Personal information
- Social profile
- Hobbies
- Testimonial
- Awards
- Portfolio
- Quick contact



